import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lms1',
  templateUrl: './lms1.component.html',
  styleUrls: ['./lms1.component.scss']
})
export class Lms1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
