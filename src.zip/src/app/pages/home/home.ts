import { Component } from '@angular/core';

@Component({
  selector: 'home',
  templateUrl: './home.html'
})

export class HomePage {
}
