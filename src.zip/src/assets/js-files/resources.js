[
    {
        "id": "res-1",
        "name": "remove fence",
        "type": "video",
        "last modified": "5 min",

    },
    {
        "id": "r2",
        "title": "product motion",
        "type": "pdf",
        "last modified": "15 min",

    },
    {
        "id": "r3",
        "name": "graphic design",
        "type": "zip",
        "last modified": "50 min",
    },
    {
        "id": "r4",
        "name": "adobe premium",
        "type": "video",
        "last modified": "20 min",

    },
    {
        "id": "r5",
        "name": "use color",
        "type": "link",
        "last modified": "12 min",

    },
    {
        "id": "r6",
        "name": "logo design",
        "type": "pdf",
        "last modified": "35 min",

    }
]