[
    {
        "userID": 1,
        "coursesInfo": {
            "name": "courses",
            "a10": {
                "name": "chapters",
                "11": {
                    "name": "topic",
                    "1": {
                        "completed": false
                    },
                    "2": {
                        "completed": false
                    },
                    "3": {
                        "completed": true
                    }
                },
                "12": {
                    "name": "topic",
                    "4": {
                        "completed": false
                    }
                },
                "13": {
                    "name": "topic",
                    "5": {
                        "completed": true
                    }
                }
            },
            "c30": {
                "name": "chapters",
                "31": {
                    "name": "topic",
                    "7": {
                        "completed": true
                    }
                },
                "32": {
                    "name": "topic",
                    "8": {
                        "completed": false
                    }
                }
            }
        }
    },
    {
        "userID": 2,
        "coursesInfo": {
            "name": "courses",
            "b20": {
                "name": "chapters",
                "21": {
                    "name": "topic",
                    "1": {
                        "completed": false
                    },
                    "2": {
                        "completed": false
                    },
                    "3": {
                        "completed": true
                    }
                },
                "22": {
                    "name": "topic",
                    "4": {
                        "completed": true
                    }
                },
                "23": {
                    "name": "topic",
                    "5": {
                        "completed": true
                    }
                },
                "24": {
                    "name": "topic",
                    "6": {
                        "completed": true
                    }
                },
                "25": {
                    "name": "topic",
                    "7": {
                        "completed": true
                    }
                }
            },
            "d40": {
                "name": "chapters",
                "41": {
                    "name": "topic",
                    "17": {
                        "completed": false
                    }
                }
            }
        }
    }


]
