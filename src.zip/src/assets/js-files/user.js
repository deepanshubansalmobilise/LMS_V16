[
    {
        "id" : 1,
        "name" : "deepanshu",
        "email" : "deepanshu@gmail.com",
        "password" : "deepanshu"
    },
    {
        "id" : 2,
        "name" : "yashu",
        "email" : "yashu@gmail.com",
        "password" : "yashu"
    },
    {
        "id" : 3,
        "name" : "sanyog",
        "email" : "sanyog@gmail.com",
        "password" : "sanyog"
    },
    {
        "id" : 4,
        "name" : "amit",
        "email" : "amit@gmail.com",
        "password" : "amit"
    },
]